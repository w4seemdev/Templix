# Eventful — Events

> Beautiful event and conference website with schedule, speakers, and tickets.

A premium React + TypeScript template from [Templix](https://templix-peach.vercel.app/).

## Tech Stack

- React
- TypeScript
- Tailwind CSS

## Pages / Sections

- Home
- Schedule
- Speakers
- Tickets
- Venue

## Getting Started

```bash
# Install dependencies
npm install

# Start dev server
npm run dev

# Build for production
npm run build
```

## Project Structure

```
├── index.html
├── package.json
├── tsconfig.json
├── vite.config.ts
└── src/
    ├── main.tsx       # Entry point
    ├── App.tsx        # Main component (your template)
    └── index.css      # Global styles
```

## Customisation

All styles are written as inline React style objects — no external CSS dependencies.
Edit `src/App.tsx` to change colors, copy, images, and layout.

## License

This template is licensed for use by the purchaser only.
Redistribution or resale is not permitted.

---
© Templix — https://templix-peach.vercel.app/
