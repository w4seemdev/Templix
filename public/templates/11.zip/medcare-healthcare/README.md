# MedCare — Healthcare

> Clean and trustworthy healthcare website for clinics and medical practices.

A responsive single-page website template built with React 19, TypeScript, Vite. The whole
site lives in `src/App.tsx` as one component composed of multiple sections (header, hero,
content sections, and footer). Styling uses self-contained inline React style objects — there
is no CSS framework or design tooling to configure.

## What's included

- Complete React + TypeScript source (Vite)
- Fully responsive mobile-first layout
- Quick-start README with setup steps
- Templix Standard License

## Getting started

Requires [Node.js](https://nodejs.org/) 18 or newer.

```bash
npm install      # install dependencies
npm run dev      # start the dev server (http://localhost:5173)
npm run build    # type-check and build for production (outputs to dist/)
npm run preview  # preview the production build locally
```

## Customising

Everything lives in `src/App.tsx`. Each section is a small function component inside that
file — edit the copy, colors, and images there. Base page styles (font and reset) are in
`src/index.css`.

## Project structure

```
├── index.html
├── package.json
├── tsconfig.json
├── tsconfig.app.json
├── tsconfig.node.json
├── vite.config.ts
└── src/
    ├── main.tsx        # entry point
    ├── App.tsx         # the template — all sections live here
    ├── index.css       # base page styles
    └── vite-env.d.ts   # Vite client types
```

## License

Templix Standard License

The purchaser may use this template in unlimited personal and commercial end-products and may modify it freely. You may NOT resell, redistribute, sublicense, or offer the template itself for download. Free templates carry the same usage terms with no purchase required.

---
© Templix
